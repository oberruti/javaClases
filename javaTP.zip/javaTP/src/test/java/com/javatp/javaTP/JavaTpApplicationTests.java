package com.javatp.javaTP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaTpApplicationTests {

	@Test
	void contextLoads() {
	}

}
